FCKLang.DrupalPageBreakTooltip = 'Insert Page Break' ;
FCKLang.DrupalPageBreakTitle = 'Page' ;
