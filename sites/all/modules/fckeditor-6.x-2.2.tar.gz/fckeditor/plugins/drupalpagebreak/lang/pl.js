FCKLang.DrupalPageBreakTooltip = 'Wstaw znacznik nowej strony' ;
FCKLang.DrupalPageBreakTitle = 'Strona' ;
